package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.entities.Location;
import com.demo.entities.Posts;
import com.demo.entities.Users;
import com.demo.repo.LocRepo;
import com.demo.repo.PostRepo;
import com.demo.repo.UserRepo;

@SpringBootApplication
public class JpaAsgnmntApplication  implements CommandLineRunner {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private PostRepo postRepo;

	@Autowired
	private LocRepo locRepo;

	public static void main(String[] args) {
		SpringApplication.run(JpaAsgnmntApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Location l1 = new Location("hyderabad");
		Location l2 = new Location("chennai");
		Location l3 = new Location("sikkim");

		Users u1 = new Users("swathi", "reddy", "swathi@gmail.com", l1);
		Users u2 = new Users("preethi", "rao", "preethi@gmail.com", l2);
		Users u3 = new Users("raju", "goud", "raj@gmail.com", l3);

		Posts p1 = new Posts("Abot java", "All", "java is a PL book", u1);
		Posts p2 = new Posts("sales", "some", "about sales", u2);
		Posts p3 = new Posts("mechanical", "public", "about machine", u3);

		l1.getUser().add(u1);
		l2.getUser().add(u2);
		l3.getUser().add(u3);

		u1.getPosts().add(p1);
		u2.getPosts().add(p2);
		u3.getPosts().add(p3);

		locRepo.save(l1);
		locRepo.save(l2);
		locRepo.save(l3);

		userRepo.save(u1);
		userRepo.save(u2);
		userRepo.save(u3);

		postRepo.save(p1);
		postRepo.save(p2);
		postRepo.save(p3);

	}

}
