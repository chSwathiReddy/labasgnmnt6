package com.demo;


import java.time.LocalDate;
import java.time.Month;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.demo.entities.Course;
import com.demo.entities.Student;
import com.demo.repo.CourseRepo;
import com.demo.repo.StudentRepo;

@SpringBootApplication
public class JpaMtmAsgnmntApplication implements CommandLineRunner{
	@Autowired
	private StudentRepo studRepo;
	@Autowired
	private CourseRepo courseRepo;
	public static void main(String[] args) {
		SpringApplication.run(JpaMtmAsgnmntApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		Student st1 = new Student("swathi") ;
		Student  st2 = new Student("preethi") ;
		Student  st3 = new Student("srujana") ;
		Student  st4 = new Student("supriya") ;
		
		Course c1 = new Course("java", LocalDate.of(2021, Month.JANUARY, 26));
		Course c2 = new Course("C",LocalDate.of(2021, Month.FEBRUARY, 21));
		
	    c1.getStudents().add(st1);
		c1.getStudents().add(st2);
		
		c2.getStudents().add(st3);
		c2.getStudents().add(st4);
		
		st1.getCourses().add(c1);
		st2.getCourses().add(c1);
		st3.getCourses().add(c2);
		st4.getCourses().add(c2);
		
		courseRepo.save(c1);
		courseRepo.save(c2);
		
		studRepo.save(st1);
		studRepo.save(st2);
		studRepo.save(st3);
		studRepo.save(st3);
		
		
		
	}

}
